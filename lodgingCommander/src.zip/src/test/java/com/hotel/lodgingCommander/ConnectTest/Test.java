package com.hotel.lodgingCommander.ConnectTest;

public class Test {

    public String chenghaTest(){
        return "connect success";
    }
}
