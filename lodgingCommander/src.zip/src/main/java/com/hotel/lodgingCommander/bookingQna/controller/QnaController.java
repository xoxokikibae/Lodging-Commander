package com.hotel.lodgingCommander.bookingQna.controller;

public class QnaController {
}
