package com.hotel.lodgingCommander.Faq.service;

import org.springframework.stereotype.Service;

@Service
public class FaqService {
}
