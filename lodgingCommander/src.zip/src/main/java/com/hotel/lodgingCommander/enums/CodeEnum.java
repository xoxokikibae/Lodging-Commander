package com.hotel.lodgingCommander.enums;

public interface CodeEnum<T>{
    T getCode();
}

