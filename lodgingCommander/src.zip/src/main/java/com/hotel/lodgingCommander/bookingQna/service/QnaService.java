package com.hotel.lodgingCommander.bookingQna.service;

public class QnaService {
}
