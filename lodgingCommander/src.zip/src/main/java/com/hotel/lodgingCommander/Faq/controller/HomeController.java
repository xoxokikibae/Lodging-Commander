package com.hotel.lodgingCommander.Faq.controller;

public class HomeController {
}
